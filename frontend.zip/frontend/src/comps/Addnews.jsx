import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../styles/addnews.css";

const AddNews = () => {
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    author: "",
    category: "Politics"
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:3000/addarticle", formData);
    navigate("/");
  };

  return (
    <div className="form-container">
    
      <h2>Add News</h2>
      <form onSubmit={handleSubmit} className="news-form">
        <input type="text" name="title" placeholder="Title" onChange={handleChange} required /> <br />
        <textarea name="content" placeholder="Content" onChange={handleChange} required /> <br />
        <input type="text" name="author" placeholder="Author" onChange={handleChange} required /> <br />
        <select name="category" onChange={handleChange}>
          <option value="Politics">Politics</option>
          <option value="Sports">Sports</option>
          <option value="Technology">Technology</option>
          <option value="Entertainment">Entertainment</option>
        </select> <br />
        <button type="submit">Submit</button>
      </form>

    </div>
  );
};

export default AddNews;
