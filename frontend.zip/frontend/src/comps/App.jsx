import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AddNews from "./Addnews";
import EditNews from "./Editnews";
import Navbar from "./Navbar";
import NewsList from "./NewsList";

function App() {
  return (
    
    <Router>
      <Routes>
        <Route path="/" element={<Navbar></Navbar>} />
        <Route path="/news-details" element={<NewsList></NewsList>} />
        <Route path="/add-news" element={<AddNews></AddNews>} />
        <Route path="/edit-news/:id" element={<EditNews></EditNews>} />
      </Routes>
    </Router>
  );
}

export default App;