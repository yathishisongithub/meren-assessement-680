import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";
import "../styles/editnews.css";

const EditNews = () => {
  const { id } = useParams();
  const [formData, setFormData] = useState({ name: "", description: "", imageUrl: "" });
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`http://localhost:3000/products/${id}`)
      .then(response => setFormData(response.data))
      .catch(error => console.error("Error fetching news:", error));
  }, [id]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:3000/products/${id}`, formData);
    navigate("/");
  };

  return (
    <div className="form-container">
      <h2>Edit News</h2>
      <form onSubmit={handleSubmit} className="news-form">
        <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        <textarea name="description" value={formData.description} onChange={handleChange} required />
        <input type="text" name="imageUrl" value={formData.imageUrl} onChange={handleChange} />
        <button type="submit">Update</button>
      </form>
    </div>
  );
};

export default EditNews;
