import React from "react";
import { Link } from "react-router-dom";
import "../styles/navbar.css";

const Navbar = () => {
  return (
    <nav className="navbar">
      <h1>News Media App</h1>
      <div className="nav-links">
        <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/add-news">Add News</Link></li>
        <li><Link to="/news-details">News List</Link></li>
        
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
