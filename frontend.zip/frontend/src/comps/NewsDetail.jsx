import React from "react";
import { useParams } from "react-router-dom";

const NewsDetail = () => {
  const { id } = useParams();
  
  return (
    <div>
      <h2>News Article {id}</h2>
      <p>Full article details will be displayed here...</p>
    </div>
    
  );
};

export default NewsDetail;
