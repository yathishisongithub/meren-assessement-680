import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const NewsList = () => {
  const [news, setNews] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/viewarticles")
      .then(response => setNews(response.data))
      .catch(error => console.error("Error fetching news:", error));
  }, []);

  return (
    <div className="news-container">
      <h2>Latest News</h2>
      {news.map(article => (
        <div key={article._id} className="news-card">
          <h3>{article.title}</h3>
          <p>{article.content}</p>
          <p><strong>Author:</strong> {article.author}</p>
          <p><strong>Category:</strong> {article.category}</p>
          <Link to={`/edit-news/${article._id}`} className="read-more">Edit</Link>
        </div>
      ))}
    </div>
  );
};

export default NewsList;
